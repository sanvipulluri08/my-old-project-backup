import { createServerFn } from "@tanstack/react-start";
import { generateText, Output } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

const InputSchema = z.object({
  scenario: z.string().min(1),
  response: z.string().min(1),
  nurses: z.number().int().min(0),
  doctors: z.number().int().min(0),
  floorStatus: z.string().min(1),
});

const ScorecardSchema = z.object({
  overallGrade: z.enum(["A", "B", "C", "D", "F"]),
  triageScore: z.number().int().min(0).max(5),
  delegationScore: z.number().int().min(0).max(5),
  feedback: z.string(),
  missedStep: z.string(),
});

export type Scorecard = z.infer<typeof ScorecardSchema>;

export const gradeResponse = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    const gateway = createLovableAiGatewayProvider(key);

    const system = `You are a critical, realistic Emergency Room Charge Nurse Supervisor with 20 years of trauma experience. You grade trainee triage responses harshly but fairly. You look for FATAL ERRORS such as:
- Leaving a crashing/coding patient alone or unattended
- Assigning tasks to staff explicitly noted as unavailable (in surgery, on break, mid-procedure)
- Delegating procedures to staff outside their scope (e.g., asking a nurse to intubate without orders)
- Ignoring the highest-acuity patient to handle lower-acuity issues
- Failing to call for help / activate codes when clearly indicated
- Skipping ABCs (airway, breathing, circulation) on an arresting patient

Grade scale:
- A: Textbook. Correct prioritization, realistic delegation given available staff, calls for backup, addresses ABCs.
- B: Solid with a minor omission.
- C: Acceptable but missed an important step or made a small delegation error.
- D: Significant clinical or delegation error; patient outcome at risk.
- F: Fatal error — patient will likely die, or delegated a critical task to staff who are unavailable.

Be concise and clinical. Feedback must be exactly 2 sentences. The "missedStep" is the single most important clinical action they should have taken first.`;

    const prompt = `SCENARIO:
${data.scenario}

AVAILABLE STAFF: ${data.nurses} nurse(s), ${data.doctors} doctor(s). Floor status: ${data.floorStatus}.

TRAINEE RESPONSE:
"""
${data.response}
"""

Grade this response now.`;

    const { output } = await generateText({
      model: gateway("google/gemini-3-flash-preview"),
      system,
      prompt,
      output: Output.object({ schema: ScorecardSchema }),
    });

    return output as Scorecard;
  });