import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import { useServerFn } from "@tanstack/react-start";
import { gradeResponse, type Scorecard } from "@/lib/grade.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Activity,
  AlertTriangle,
  Clock,
  Users,
  User,
  ShieldAlert,
  Send,
  CheckCircle,
  RotateCcw,
  Stethoscope,
  Loader2,
  GraduationCap,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ER Crisis Drill Simulator" },
      { name: "description", content: "Hospital emergency room mock-drill simulator for training triage responses." },
    ],
  }),
  component: Index,
});

const FLOOR_STATUS_OPTIONS = [
  { value: "calm", label: "Calm", color: "text-emerald-600" },
  { value: "busy", label: "Busy", color: "text-amber-600" },
  { value: "critical-chaos", label: "Critical Chaos", color: "text-alert" },
];

const PLACEHOLDER_SCENARIO =
  "ALERT: Bed 3 is in cardiac arrest. Doctor A is stuck in surgery. You have 2 nurses on the floor. What do you do?";

// ============= Scenario Generator =============
const EMERGENCIES = [
  { code: "CARDIAC ARREST", detail: "no pulse, CPR in progress" },
  { code: "MASSIVE GI BLEED", detail: "BP 70/40 and dropping" },
  { code: "ANAPHYLAXIS", detail: "airway swelling, stridor audible" },
  { code: "STROKE ALERT", detail: "left-side hemiplegia, last known well 45 min ago" },
  { code: "MULTI-VEHICLE TRAUMA", detail: "3 incoming via EMS, ETA 4 minutes" },
  { code: "PEDIATRIC SEIZURE", detail: "4-year-old, status epilepticus, 12 minutes active" },
  { code: "GUNSHOT WOUND", detail: "chest entry, breath sounds absent on right" },
  { code: "SEPTIC SHOCK", detail: "lactate 6.2, febrile, altered mental status" },
  { code: "OPIOID OVERDOSE", detail: "RR 4, pinpoint pupils, cyanotic" },
  { code: "OBSTETRIC EMERGENCY", detail: "cord prolapse, 38 weeks gestation" },
  { code: "DKA CRISIS", detail: "glucose 680, Kussmaul breathing, vomiting" },
  { code: "ACTIVE STEMI", detail: "ST elevation V1-V4, cath lab not ready" },
  { code: "BURN VICTIM", detail: "40% TBSA, electrical, airway compromise" },
  { code: "PSYCHIATRIC CODE", detail: "patient combative, threatening staff with IV pole" },
];

const BEDS = ["Bed 1", "Bed 3", "Bed 7", "Bed 12", "Trauma Bay 2", "Hallway Stretcher 4", "Triage Room B"];

const PATIENT_SYMPTOMS = [
  "deteriorating O2 sats (82% on NRB)",
  "vomiting blood",
  "screaming in 10/10 pain",
  "unresponsive to sternal rub",
  "actively seizing",
  "has ripped out their IV and is wandering",
  "developing a widening pulse pressure",
  "showing agonal breathing",
  "throwing PVCs on the monitor",
];

const STAFF_ROADBLOCKS = [
  "the attending is scrubbed into emergency surgery upstairs",
  "the only intubation-credentialed physician is on a mandatory break",
  "two nurses just called out for the next shift",
  "the charge nurse is on the phone with the on-call surgeon and can't disengage",
  "a resident is mid-procedure and refuses to hand off",
  "the physician is stuck doing a family death notification",
  "your senior nurse twisted an ankle during a transfer",
];

const SYSTEM_FAILURES = [
  "the EMR just went down — paper charting only",
  "blood bank reports a 20-minute delay on O-neg",
  "CT scanner is offline for emergency maintenance",
  "the crash cart in zone B is missing epinephrine",
  "ICU reports zero open beds, hold orders in effect",
  "the pharmacy tube system is jammed",
  "fire alarm just tripped on the floor above — possible evacuation",
  "a code is also being called in the waiting room",
];

const WAITING_ROOM = [
  "waiting room has 14 patients, 3 chest pains untriaged",
  "an angry family member is demanding to see the charge nurse",
  "EMS radio reports 2 more critical inbounds",
  "a walk-in just collapsed in the lobby",
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function pickN<T>(arr: T[], n: number): T[] {
  const copy = [...arr];
  const out: T[] = [];
  for (let i = 0; i < n && copy.length; i++) {
    out.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0]);
  }
  return out;
}

function generateScenario(nurses: number, doctors: number, floorStatus: string): string {
  const chaosWeight =
    floorStatus === "critical-chaos" ? 3 : floorStatus === "busy" ? 2 : 1;

  const primary = pick(EMERGENCIES);
  const bed = pick(BEDS);

  const staffThin = nurses + doctors < 4;
  const complicationCount = Math.min(4, chaosWeight + (staffThin ? 1 : 0) - 1);

  const complications: string[] = [];

  const secondBed = pick(BEDS.filter((b) => b !== bed));
  complications.push(`${secondBed} is ${pick(PATIENT_SYMPTOMS)}`);

  if (doctors <= 2 || chaosWeight >= 2) {
    complications.push(pick(STAFF_ROADBLOCKS));
  }

  const systemPicks = pickN(SYSTEM_FAILURES, Math.max(0, complicationCount - 1));
  complications.push(...systemPicks);

  if (floorStatus === "critical-chaos") {
    complications.push(pick(WAITING_ROOM));
  }

  const staffLine =
    nurses === 0 && doctors === 0
      ? "You have NO staff on the floor."
      : `You have ${nurses} nurse${nurses === 1 ? "" : "s"} and ${doctors} doctor${doctors === 1 ? "" : "s"} on the floor.`;

  const opener =
    floorStatus === "critical-chaos"
      ? "CODE ALERT — CRITICAL CHAOS:"
      : floorStatus === "busy"
        ? "ALERT:"
        : "INCOMING:";

  return `${opener} ${bed} is in ${primary.code} — ${primary.detail}. Meanwhile, ${complications.join("; ")}. ${staffLine} What do you do?`;
}

function formatTime(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function StatusBadge({ status }: { status: string }) {
  const option = FLOOR_STATUS_OPTIONS.find((o) => o.value === status);
  if (!option) return null;

  const bgMap: Record<string, string> = {
    calm: "bg-emerald-50",
    busy: "bg-amber-50",
    "critical-chaos": "bg-red-50",
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wider ${bgMap[status]} ${option.color}`}
    >
      {status === "critical-chaos" && <AlertTriangle className="h-3.5 w-3.5" />}
      {option.label}
    </span>
  );
}

function Index() {
  const [nurses, setNurses] = useState<string>("2");
  const [doctors, setDoctors] = useState<string>("1");
  const [floorStatus, setFloorStatus] = useState<string>("busy");

  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120);
  const [scenario, setScenario] = useState(PLACEHOLDER_SCENARIO);
  const [showSimulation, setShowSimulation] = useState(false);

  const [response, setResponse] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [grading, setGrading] = useState(false);
  const [scorecard, setScorecard] = useState<Scorecard | null>(null);
  const [gradeError, setGradeError] = useState<string | null>(null);
  const [showScorecard, setShowScorecard] = useState(false);

  const gradeFn = useServerFn(gradeResponse);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            if (intervalRef.current) clearInterval(intervalRef.current);
            setIsRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, timeLeft]);

  const handleGenerate = () => {
    const n = Math.max(0, parseInt(nurses || "0", 10));
    const d = Math.max(0, parseInt(doctors || "0", 10));
    setScenario(generateScenario(n, d, floorStatus));
    setTimeLeft(120);
    setIsRunning(true);
    setShowSimulation(true);
    setSubmitted(false);
    setResponse("");
  };

  const handleReset = () => {
    setIsRunning(false);
    setShowSimulation(false);
    setSubmitted(false);
    setResponse("");
    setTimeLeft(120);
    setScorecard(null);
    setGradeError(null);
    setShowScorecard(false);
  };

  const handleSubmit = async () => {
    if (response.trim().length === 0 || grading) return;
    setGrading(true);
    setGradeError(null);
    setIsRunning(false);
    try {
      const result = await gradeFn({
        data: {
          scenario,
          response: response.trim(),
          nurses: Math.max(0, parseInt(nurses || "0", 10)),
          doctors: Math.max(0, parseInt(doctors || "0", 10)),
          floorStatus,
        },
      });
      setScorecard(result);
      setShowScorecard(true);
      setSubmitted(true);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Grading failed. Please try again.";
      setGradeError(msg);
    } finally {
      setGrading(false);
    }
  };

  const isAlertActive = isRunning && timeLeft <= 30;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <Stethoscope className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-foreground">
                Crisis Drill Simulator
              </h1>
              <p className="text-xs text-muted-foreground">Emergency Response Training</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isRunning ? (
              <div className="flex items-center gap-2 rounded-full bg-destructive/10 px-3 py-1.5">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive opacity-75" />
                  <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-destructive" />
                </span>
                <span className="text-xs font-semibold text-destructive uppercase tracking-wider">
                  Live Drill
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 rounded-full bg-muted px-3 py-1.5">
                <ShieldAlert className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Standby
                </span>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-6 py-8">
        {/* Input Section */}
        <section className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <div className="mb-5 flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            <h2 className="text-sm font-semibold uppercase tracking-wider text-foreground">
              Floor Configuration
            </h2>
          </div>

          <div className="grid gap-5 sm:grid-cols-3">
            <div className="space-y-2">
              <label htmlFor="nurses" className="flex items-center gap-1.5 text-sm font-medium text-foreground">
                <User className="h-3.5 w-3.5 text-muted-foreground" />
                Nurses on Duty
              </label>
              <Input
                id="nurses"
                type="number"
                min={0}
                max={50}
                value={nurses}
                onChange={(e) => setNurses(e.target.value)}
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="doctors" className="flex items-center gap-1.5 text-sm font-medium text-foreground">
                <Stethoscope className="h-3.5 w-3.5 text-muted-foreground" />
                Doctors on Duty
              </label>
              <Input
                id="doctors"
                type="number"
                min={0}
                max={50}
                value={doctors}
                onChange={(e) => setDoctors(e.target.value)}
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="floor-status" className="flex items-center gap-1.5 text-sm font-medium text-foreground">
                <Activity className="h-3.5 w-3.5 text-muted-foreground" />
                Floor Status
              </label>
              <Select value={floorStatus} onValueChange={setFloorStatus}>
                <SelectTrigger id="floor-status" className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FLOOR_STATUS_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="mt-5 flex items-center gap-3">
            <StatusBadge status={floorStatus} />
            <span className="text-xs text-muted-foreground">
              {parseInt(nurses || "0")} nurses · {parseInt(doctors || "0")} doctors configured
            </span>
          </div>
        </section>

        {/* Trigger */}
        <div className="mt-6">
          <Button
            onClick={handleGenerate}
            disabled={isRunning}
            size="lg"
            className="w-full gap-2 bg-destructive py-6 text-base font-bold uppercase tracking-wider text-destructive-foreground shadow-lg shadow-destructive/20 hover:bg-destructive/90 disabled:opacity-40"
          >
            <AlertTriangle className="h-5 w-5" />
            Generate Random Crisis Drill
          </Button>
        </div>

        {/* Simulation Box */}
        {showSimulation && (
          <section className={`mt-6 animate-slide-up rounded-xl border-2 p-6 shadow-lg ${isAlertActive ? "border-destructive bg-destructive/5" : "border-border bg-card"}`}>
            {/* Timer + Status */}
            <div className="mb-5 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-full ${isAlertActive ? "bg-destructive text-destructive-foreground animate-pulse-red" : "bg-primary text-primary-foreground"}`}
                >
                  <Clock className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Time Remaining
                  </p>
                  <p
                    className={`font-mono text-3xl font-bold tracking-tight ${isAlertActive ? "text-destructive" : "text-foreground"}`}
                  >
                    {formatTime(timeLeft)}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {isRunning ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-destructive/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-destructive">
                    <span className="relative flex h-2 w-2">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive opacity-75" />
                      <span className="relative inline-flex h-2 w-2 rounded-full bg-destructive" />
                    </span>
                    Drill Active
                  </span>
                ) : timeLeft === 0 ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Time Expired
                  </span>
                ) : null}
                <Button variant="outline" size="sm" onClick={handleReset} className="gap-1">
                  <RotateCcw className="h-3.5 w-3.5" />
                  Reset
                </Button>
              </div>
            </div>

            {/* Progress bar */}
            <div className="mb-5 h-2 w-full overflow-hidden rounded-full bg-muted">
              <div
                className={`h-full rounded-full transition-all duration-1000 ease-linear ${isAlertActive ? "bg-destructive" : "bg-primary"}`}
                style={{ width: `${(timeLeft / 120) * 100}%` }}
              />
            </div>

            {/* Scenario */}
            <div
              className={`rounded-lg border p-5 ${isAlertActive ? "border-destructive/30 bg-destructive/5" : "border-border bg-background"}`}
            >
              <div className="mb-3 flex items-center gap-2">
                <AlertTriangle className={`h-4 w-4 ${isAlertActive ? "text-destructive" : "text-primary"}`} />
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  Scenario
                </span>
              </div>
              <p className="text-lg font-semibold leading-relaxed text-foreground">
                {scenario}
              </p>
            </div>
          </section>
        )}

        {/* Response Section */}
        {showSimulation && !submitted && (
          <section className="mt-6 animate-slide-up rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="mb-4 flex items-center gap-2">
              <Send className="h-4 w-4 text-primary" />
              <h2 className="text-sm font-semibold uppercase tracking-wider text-foreground">
                Triage Response
              </h2>
            </div>

            <div className="space-y-4">
              <Textarea
                placeholder="Type your immediate triage action response here"
                value={response}
                onChange={(e) => setResponse(e.target.value)}
                className="min-h-[140px] resize-none bg-background text-base leading-relaxed"
                disabled={grading}
              />
              {gradeError && (
                <div className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
                  {gradeError}
                </div>
              )}
              <Button
                onClick={handleSubmit}
                disabled={response.trim().length === 0 || grading}
                className="w-full gap-2 bg-primary py-5 text-sm font-semibold uppercase tracking-wider text-primary-foreground hover:bg-primary/90"
              >
                {grading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Charge Nurse Reviewing...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    Submit Response
                  </>
                )}
              </Button>
            </div>
          </section>
        )}

        {/* Submitted confirmation */}
        {submitted && scorecard && (
          <section className="mt-6 animate-slide-up rounded-xl border border-border bg-card p-8 text-center shadow-sm">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50">
              <CheckCircle className="h-7 w-7 text-emerald-600" />
            </div>
            <h3 className="mt-4 text-lg font-bold text-foreground">Response Graded</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Charge Nurse Supervisor returned an assessment.
            </p>
            <div className="mt-5 flex flex-wrap justify-center gap-2">
              <Button variant="outline" onClick={() => setShowScorecard(true)} className="gap-1">
                <GraduationCap className="h-3.5 w-3.5" />
                View Scorecard
              </Button>
              <Button variant="outline" onClick={handleReset} className="gap-1">
                <RotateCcw className="h-3.5 w-3.5" />
                Start New Drill
              </Button>
            </div>
          </section>
        )}

        {/* Scorecard Modal */}
        <Dialog open={showScorecard} onOpenChange={setShowScorecard}>
          <DialogContent className="sm:max-w-lg">
            {scorecard && (
              <>
                <DialogHeader>
                  <div className="flex items-center gap-2">
                    <GraduationCap className="h-5 w-5 text-primary" />
                    <DialogTitle className="text-base font-bold uppercase tracking-wider">
                      Charge Nurse Scorecard
                    </DialogTitle>
                  </div>
                  <DialogDescription className="text-xs text-muted-foreground">
                    Critical assessment from your ER Supervisor
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-5 py-2">
                  {/* Overall Grade */}
                  <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-muted/30 p-6">
                    <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      Overall Grade
                    </span>
                    <span
                      className={`mt-2 font-mono text-7xl font-black ${
                        scorecard.overallGrade === "A"
                          ? "text-emerald-600"
                          : scorecard.overallGrade === "B"
                            ? "text-emerald-500"
                            : scorecard.overallGrade === "C"
                              ? "text-amber-500"
                              : scorecard.overallGrade === "D"
                                ? "text-orange-600"
                                : "text-destructive"
                      }`}
                    >
                      {scorecard.overallGrade}
                    </span>
                  </div>

                  {/* Sub-scores */}
                  <div className="grid grid-cols-2 gap-3">
                    <ScoreBar label="Triage" score={scorecard.triageScore} />
                    <ScoreBar label="Staff Delegation" score={scorecard.delegationScore} />
                  </div>

                  {/* Feedback */}
                  <div className="rounded-lg border border-border bg-background p-4">
                    <div className="mb-2 flex items-center gap-1.5">
                      <AlertTriangle className="h-3.5 w-3.5 text-primary" />
                      <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                        Supervisor Feedback
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed text-foreground">{scorecard.feedback}</p>
                  </div>

                  {/* Missed step */}
                  <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-4">
                    <div className="mb-2 flex items-center gap-1.5">
                      <ShieldAlert className="h-3.5 w-3.5 text-destructive" />
                      <span className="text-xs font-bold uppercase tracking-wider text-destructive">
                        Critical Step Missed
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed text-foreground">{scorecard.missedStep}</p>
                  </div>
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowScorecard(false)}>
                    Close
                  </Button>
                  <Button onClick={handleReset} className="gap-1">
                    <RotateCcw className="h-3.5 w-3.5" />
                    New Drill
                  </Button>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}

function ScoreBar({ label, score }: { label: string; score: number }) {
  const pct = (score / 5) * 100;
  const color =
    score >= 4 ? "bg-emerald-500" : score >= 3 ? "bg-amber-500" : "bg-destructive";
  return (
    <div className="rounded-lg border border-border bg-background p-3">
      <div className="flex items-baseline justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <span className="font-mono text-sm font-bold text-foreground">{score}/5</span>
      </div>
      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div className={`h-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}